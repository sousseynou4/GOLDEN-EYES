# 🚀 Déploiement sur Vercel — Guide pas-à-pas

Ce guide te permettra de mettre **golden-eyes.eu** en ligne en **15 minutes**.

---

## 📋 Prérequis

- ✅ Un compte **GitHub** (gratuit) → https://github.com
- ✅ Un compte **Vercel** (gratuit) → https://vercel.com
- ✅ Ton code Golden Eyes (le dossier `golden-eyes-v8`)
- ✅ Ton domaine `golden-eyes.eu` (déjà acheté)

---

## Étape 1 · Pousser le code sur GitHub (5 min)

### a) Crée un nouveau repo sur GitHub

1. Va sur https://github.com → bouton **+** en haut → **New repository**
2. Nom : `golden-eyes`
3. Visibilité : **Private** (ton code reste privé)
4. **NE COCHE RIEN** (pas de README, pas de .gitignore — on a déjà tout)
5. Clique **Create repository**

### b) Pousse ton code depuis ton ordinateur

Ouvre un terminal PowerShell **dans ton dossier** `golden-eyes-v8` :

```powershell
cd D:\TELECHAGEMENT\golden-eyes-v8

# Initialise git
git init

# Ajoute tous les fichiers
git add .

# Premier commit
git commit -m "Golden Eyes - site complet"

# Connecte au repo GitHub (remplace TON_USERNAME par ton pseudo GitHub)
git remote add origin https://github.com/TON_USERNAME/golden-eyes.git

# Pousse
git branch -M main
git push -u origin main
```

> 💡 Si Git te demande de te connecter, entre ton pseudo GitHub et ton
> **Personal Access Token** (pas ton mot de passe).
> Pour créer un token : GitHub → Settings → Developer settings →
> Personal access tokens → Generate new token (cocher `repo`).

---

## Étape 2 · Connecter Vercel au repo GitHub (3 min)

1. Va sur **https://vercel.com** → connecte-toi (ou crée un compte avec GitHub)
2. Clique **Add New...** → **Project**
3. Tu vois ton repo `golden-eyes` → clique **Import**
4. ⚠️ **IMPORTANT** : Dans les réglages avant de déployer :

### Framework Preset
→ Sélectionne **Next.js** (normalement auto-détecté)

### Environment Variables
C'est ici que tu mets tes clés secrètes (celles de ton `.env.local`).

Clique **Environment Variables** et ajoute **chacune de ces lignes** :

| Nom (Name) | Valeur (Value) |
|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | `https://siljarpldrchilnqnuvh.supabase.co` |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | ta clé anon (la longue `eyJ...`) |
| `SUPABASE_SERVICE_ROLE_KEY` | ta clé service_role |
| `NEXT_PUBLIC_APP_URL` | `https://golden-eyes.eu` |
| `RESEND_API_KEY` | ta clé Resend (`re_...`) |
| `EMAIL_FROM` | `Golden Eyes <contact@golden-eyes.eu>` |
| `ADMIN_EMAIL` | `almamy70@gmail.com` |

> ⚠️ **Très important** : REGENERE d'abord tes clés Supabase et Resend
> avant de les mettre ici (puisque les anciennes ont été partagées
> dans notre conversation).

5. Clique **Deploy**
6. Attends 1-2 minutes... ✅ **Ton site est en ligne !**

Vercel te donne une URL temporaire genre `golden-eyes-xxxx.vercel.app`.
Vérifie que tout marche dessus avant de brancher ton domaine.

---

## Étape 3 · Brancher ton domaine `golden-eyes.eu` (5 min)

### a) Sur Vercel

1. Dans ton projet Vercel → onglet **Settings** → **Domains**
2. Tape `golden-eyes.eu` → **Add**
3. Tape aussi `www.golden-eyes.eu` → **Add**
4. Vercel t'affiche les **enregistrements DNS** à ajouter

### b) Chez ton hébergeur de domaine

Va sur le site où tu as acheté `golden-eyes.eu`, section **DNS** ou **Zone DNS**.

Ajoute ces enregistrements (Vercel te les donne, mais voici le schéma type) :

#### Pour `golden-eyes.eu` (domaine nu) :
| Type | Nom / Hôte | Valeur |
|------|-----------|--------|
| **A** | `@` | `76.76.21.21` |

#### Pour `www.golden-eyes.eu` :
| Type | Nom / Hôte | Valeur |
|------|-----------|--------|
| **CNAME** | `www` | `cname.vercel-dns.com` |

> ⏰ **Patience** : les DNS mettent 5 à 30 minutes à se propager
> (parfois jusqu'à 48h dans le pire des cas, mais c'est rare).

### c) Vérification

Retourne sur Vercel → Settings → Domains. Quand le badge passe au **vert** ✅,
ton site est accessible sur **https://golden-eyes.eu** !

Vercel s'occupe automatiquement :
- Du **certificat SSL** (HTTPS, le cadenas) → gratuit
- De la **redirection** www → non-www (ou l'inverse, selon ta préférence)
- Du **CDN mondial** (ton site est rapide partout dans le monde)

---

## Étape 4 · Déploiements automatiques (bonus gratuit)

À partir de maintenant, **chaque fois que tu pousses sur GitHub**, Vercel
redéploie automatiquement. C'est le workflow idéal :

```powershell
# Après avoir modifié du code :
git add .
git commit -m "Mise à jour du portfolio"
git push
```

→ En 1-2 min, la nouvelle version est en ligne. Pas de serveur à gérer,
pas de commande compliquée.

---

## 🧪 Checklist post-déploiement

- [ ] `https://golden-eyes.eu` → la page d'accueil s'affiche
- [ ] La navigation fonctionne (Portfolio, À propos, Contact)
- [ ] Le formulaire de contact → envoie sans erreur
- [ ] `https://golden-eyes.eu/login` → page de connexion admin
- [ ] Connexion → dashboard accessible
- [ ] Les images de démo s'affichent (ou tes propres photos si tu en as uploadé)
- [ ] Le QR code de ta carte de visite → pointe vers le bon site

---

## 🆘 Problèmes fréquents

### "Build failed" sur Vercel
→ Vérifie que **TOUTES** les variables d'environnement sont remplies.
La plus oubliée : `NEXT_PUBLIC_APP_URL`.

### Les images ne s'affichent pas
→ Vérifie que `images.unsplash.com` et ton projet Supabase sont bien
dans la config `next.config.ts` (c'est déjà fait dans le code livré).

### "Cannot find module" en production
→ Force un redéploiement : Vercel → Deployments → les 3 points →
**Redeploy** (coche "Clear Build Cache").

### Le domaine affiche "DNS_PROBE_FINISHED_NXDOMAIN"
→ Les DNS ne se sont pas encore propagés. Attends 30 minutes et réessaie.
Utilise https://dnschecker.org pour vérifier la propagation.

### Les emails ne partent pas en production
→ Vérifie que `RESEND_API_KEY` et `EMAIL_FROM` sont bien dans les
variables Vercel (pas seulement dans ton `.env.local` local !).

---

## 💰 Coûts

| Service | Plan gratuit | Limite |
|---------|-------------|--------|
| **Vercel** | Hobby (gratuit) | 100 Go bande passante/mois |
| **Supabase** | Free | 500 Mo DB, 1 Go stockage |
| **Resend** | Free | 3000 emails/mois |
| **GitHub** | Free | Repos privés illimités |

→ **Ton site entier tourne gratuitement** tant que tu restes dans ces limites
(largement suffisant pour un photographe indépendant).
